from typing import List

from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import require_admin
from app.schemas.user_schemas import AdminEmailUpdate, UserCreateByAdmin, UserResponse
from app.services.auth_service import AuthService
from app.repositories.user_repo import UserRepository

router = APIRouter(prefix="/users", tags=["users"])


@router.post("", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def create_user_by_admin(
    payload: UserCreateByAdmin,
    db: Session = Depends(get_db),
    _admin=Depends(require_admin),
):
    return AuthService.create_user_by_admin(
        db=db,
        full_name=payload.full_name,
        email=payload.email,
        role=payload.role,
    )


@router.get("", response_model=List[UserResponse])
def list_users(
    db: Session = Depends(get_db),
    _admin=Depends(require_admin),
):
    return UserRepository.list_all(db)


@router.patch("/{user_id}/email", response_model=UserResponse)
def update_user_email_as_admin(
    user_id: int,
    payload: AdminEmailUpdate,
    db: Session = Depends(get_db),
    _admin=Depends(require_admin),
):
    return AuthService.admin_update_user_email(
        db=db,
        user_id=user_id,
        email=payload.email,
    )