from datetime import date
import os

from services.inference_service.app.schemas import BaseRequest


DEFAULT_STORE_ID = os.getenv("DEFAULT_STORE_ID", "MAIN_STORE")
DEFAULT_REGION = os.getenv("DEFAULT_REGION", "UNKNOWN")


def build_request_from_product(product: dict) -> BaseRequest:
    current_price = float(product.get("current_price", 0.0))
    current_stock = float(product.get("current_stock", 0.0))
    cost_price = product.get("cost_price")
    min_price = product.get("min_price")

    return BaseRequest(
        store_id=str(product.get("store_id", DEFAULT_STORE_ID)),
        product_id=str(product["product_id"]),
        date=date.today(),
        price=current_price,
        stock=current_stock,
        discount=float(product.get("discount", 0.0) or 0.0),

        # Ne plus inventer de fausses données
        competitor_pricing=None,
        units_ordered=float(product.get("units_ordered", 0.0) or 0.0),
        weather_condition=None,

        category=product.get("category"),
        region=product.get("region", DEFAULT_REGION),

        threshold_min=float(product.get("threshold_min", 0.0) or 0.0),
        threshold_max=float(product.get("threshold_max", 0.0) or 0.0),
        cost_price=float(cost_price) if cost_price is not None else None,
        min_price=float(min_price) if min_price is not None else None,
        brand=product.get("brand"),
    )