import os
import requests
from fastapi import HTTPException

STOCK_SERVICE_URL = os.getenv("STOCK_SERVICE_URL", "http://127.0.0.1:8004")


def get_product_from_stock_service(product_id: int) -> dict:
    try:
        response = requests.get(f"{STOCK_SERVICE_URL}/products/{product_id}", timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.Timeout:
        raise HTTPException(status_code=504, detail="stock_service timeout")
    except requests.RequestException as e:
        raise HTTPException(status_code=502, detail=f"Erreur stock_service: {str(e)}")