from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from services.inference_service.app.database import get_db
from services.inference_service.app.services.stock_client import get_product_from_stock_service
from services.inference_service.app.services.request_builder import build_request_from_product
from services.inference_service.app.services.demand_service import forecast_demand_service

router = APIRouter(prefix="/predict")


@router.get("/demand-weekly/{product_id}")
def predict_demand_weekly(product_id: int, db: Session = Depends(get_db)):
    product = get_product_from_stock_service(product_id)
    req = build_request_from_product(product)

    result = forecast_demand_service(req, db)

    return {
        "product_id": product_id,
        "p10": round(result.predicted_demand * 0.85, 2),
        "p50": round(result.predicted_demand, 2),
        "p90": round(result.predicted_demand * 1.15, 2),
        "explanation": f"Prévision hebdomadaire estimée autour de {result.predicted_demand:.0f} unités."
    }