from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from services.inference_service.app.database import get_db
from services.inference_service.app.services.history_service import get_product_kpis_service

router = APIRouter(prefix="/products", tags=["History KPIs"])


@router.get("/{product_id}/kpis")
def get_product_kpis(
    product_id: int,
    days: int = Query(60, ge=1, le=365),
    db: Session = Depends(get_db),
):
    return get_product_kpis_service(product_id, days, db)