from __future__ import annotations

from datetime import datetime
from typing import Optional, Set
from urllib.parse import urljoin
import re
import time
import requests
import urllib3

from bs4 import BeautifulSoup

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from app.schemas.scraping_schemas import (
    CompetitorModel,
    ProductCompetitorPayload,
    ScrapeSummary,
    CatalogScrapeDetail,
)
from app.services.stock_client import StockServiceClient
from app.services.selector_service import detect_selectors


PRICE_RE = re.compile(r"(\d[\d\s.,]*)\s*TND", re.IGNORECASE)


def normalize_text(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    return " ".join(value.split()).strip() or None


def parse_price(value: Optional[str]) -> Optional[float]:
    if not value:
        return None

    text = value.replace("\xa0", " ").strip()
    cleaned = "".join(ch for ch in text if ch.isdigit() or ch in ",.")
    if not cleaned:
        return None

    if "," in cleaned and "." in cleaned:
        if cleaned.rfind(",") > cleaned.rfind("."):
            cleaned = cleaned.replace(".", "").replace(",", ".")
        else:
            cleaned = cleaned.replace(",", "")
    else:
        cleaned = cleaned.replace(",", ".")

    try:
        return float(cleaned)
    except ValueError:
        return None


def extract_price_from_text(text: str) -> Optional[float]:
    if not text:
        return None
    m = PRICE_RE.search(text.replace("\xa0", " "))
    if not m:
        return None
    return parse_price(m.group(1))


def looks_like_product_name(text: str) -> bool:
    if not text:
        return False

    t = " ".join(text.split()).strip()
    lower = t.lower()

    banned = [
        "détails",
        "voir les détails",
        "ajouter au panier",
        "acheter",
        "connexion",
        "create an account",
        "panier",
        "menu",
        "retour",
        "suivant",
        "précédent",
    ]
    if lower in banned:
        return False

    # FIX : seuil de longueur abaissé de 12 à 8 caractères pour ne pas
    # filtrer des noms courts mais valides (ex. "HP Z2 G4")
    if len(t) < 8:
        return False

    useful_tokens = [
        "pc", "portable", "laptop", "notebook", "lenovo", "asus", "hp",
        "dell", "acer", "msi", "macbook", "iphone", "samsung", "écran",
        "ecran", "monitor", "moniteur", "ssd", "ram", "go", "tb",
        # FIX : tokens supplémentaires couvrant d'autres catégories
        "intel", "amd", "ryzen", "core", "geforce", "rtx", "gtx",
        "processeur", "memoire", "mémoire", "disque", "clavier", "souris",
        "imprimante", "tablette", "smartphone", "telephone", "téléphone",
        "onduleur", "batterie", "chargeur", "casque", "ecouteur", "écouteur",
        "routeur", "switch", "wifi", "carte", "webcam", "scanner",
    ]
    # FIX : on accepte un nom même sans token utile si le texte est assez long
    # (> 20 caractères) — heuristique pour les noms de produits atypiques
    if len(t) > 20:
        return True

    return any(tok in lower for tok in useful_tokens)


class ScrapingService:
    def __init__(self) -> None:
        self.stock_client = StockServiceClient()
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0",
            "Accept-Language": "fr,en;q=0.9",
        })

    def _absolute_url(self, base_url: str, href: Optional[str]) -> Optional[str]:
        if not href:
            return None
        return urljoin(base_url, href)

    def _get_html(self, url: str) -> str:
        last_exc = None
        for _ in range(3):
            try:
                response = self.session.get(url, timeout=(10, 45), allow_redirects=True, verify=False)
                response.raise_for_status()
                return response.text
            except Exception as exc:
                last_exc = exc
                time.sleep(1)
        raise RuntimeError(f"Echec récupération HTML pour {url}: {last_exc}")

    def _extract_product_from_card(self, card, page_url: str, selectors: dict, competitor: CompetitorModel):
        data_name = card.get("data-name")
        data_url = card.get("data-url")
        data_sku = card.get("data-sku")
        data_price = card.get("data-final-price") or card.get("data-price")

        name_node = card.select_one(selectors.get("product_name")) if selectors.get("product_name") else None
        link_node = card.select_one(selectors.get("product_link")) if selectors.get("product_link") else None
        price_node = card.select_one(selectors.get("product_price")) if selectors.get("product_price") else None
        old_price_node = card.select_one(selectors.get("old_price")) if selectors.get("old_price") else None
        availability_node = card.select_one(selectors.get("availability")) if selectors.get("availability") else None
        sku_node = card.select_one(selectors.get("sku")) if selectors.get("sku") else None

        nom_produit = data_name or (name_node.get_text(" ", strip=True) if name_node else None)

        href = data_url
        if not href and link_node and link_node.has_attr("href"):
            href = link_node.get("href")

        url_produit = self._absolute_url(page_url, href)
        prix_concurrent = parse_price(data_price or (price_node.get_text(" ", strip=True) if price_node else None))
        ancien_prix = parse_price(old_price_node.get_text(" ", strip=True)) if old_price_node else None
        disponibilite = availability_node.get_text(" ", strip=True) if availability_node else None
        sku_concurrent = data_sku or (sku_node.get_text(" ", strip=True) if sku_node else None)

        if not nom_produit or not url_produit or prix_concurrent is None:
            return None

        return ProductCompetitorPayload(
            urlProduit=url_produit,
            skuConcurrent=sku_concurrent,
            nomProduit=nom_produit,
            concurrent_id=competitor.id,
            produit_id=None,
            prixConcurrent=prix_concurrent,
            isPromo=bool(ancien_prix and ancien_prix > prix_concurrent),
            disponibilite=normalize_text(disponibilite),
            dateCollecte=datetime.utcnow().isoformat(),
            fiable=True,
        )

    def _extract_products_without_cards(self, soup: BeautifulSoup, page_url: str, competitor: CompetitorModel):
        items = []
        seen_urls = set()

        for a in soup.select("a[href]"):
            href = a.get("href")
            text = a.get_text(" ", strip=True)

            if not href or not looks_like_product_name(text):
                continue

            absolute_url = self._absolute_url(page_url, href)
            if not absolute_url or absolute_url in seen_urls:
                continue

            parent = a.parent
            price = None
            availability = None

            probe = parent
            for _ in range(4):
                if probe is None:
                    break

                probe_text = probe.get_text(" ", strip=True)
                price = extract_price_from_text(probe_text) or price

                lower_text = probe_text.lower()
                if "hors stock" in lower_text:
                    availability = "Hors stock"
                elif "en stock" in lower_text:
                    availability = "En stock"
                elif "en arrivage" in lower_text:
                    availability = "En arrivage"

                if price is not None:
                    break

                probe = probe.parent

            if price is None:
                continue

            seen_urls.add(absolute_url)
            items.append(
                ProductCompetitorPayload(
                    urlProduit=absolute_url,
                    skuConcurrent=None,
                    nomProduit=text,
                    concurrent_id=competitor.id,
                    produit_id=None,
                    prixConcurrent=price,
                    isPromo=False,
                    disponibilite=availability,
                    dateCollecte=datetime.utcnow().isoformat(),
                    fiable=False,
                )
            )

        return items

    def _extract_products_from_page(self, page_url: str, html: str, competitor: CompetitorModel):
        soup = BeautifulSoup(html, "lxml")
        host = competitor.site_host_normalized or ""
        selectors = dict(competitor.selectors_override or {})
        if not selectors.get("product_card"):
            selectors.update(detect_selectors(host, html))

        errors = []
        items = []

        product_card_sel = selectors.get("product_card")
        cards = []

        if product_card_sel:
            try:
                cards = soup.select(product_card_sel)
            except Exception as exc:
                errors.append(f"Sélecteur product_card invalide: {exc}")

        if cards:
            for card in cards:
                try:
                    item = self._extract_product_from_card(card, page_url, selectors, competitor)
                    if item:
                        items.append(item)
                except Exception as exc:
                    errors.append(f"Erreur parsing carte sur {page_url}: {str(exc)}")

        if not items:
            fallback_items = self._extract_products_without_cards(soup, page_url, competitor)
            items.extend(fallback_items)

        next_page_url = None
        next_selector = selectors.get("next_page")
        if next_selector:
            next_node = soup.select_one(next_selector)
            if next_node and next_node.has_attr("href"):
                next_page_url = self._absolute_url(page_url, next_node.get("href"))

        # FIX : fallback pagination — vérification que le lien "suivant"
        # pointe bien vers une page différente de l'URL courante
        if not next_page_url:
            for a in soup.select("a[href]"):
                txt = a.get_text(" ", strip=True).lower()
                if txt in {"suivant", "next"} or "navigate_next" in txt:
                    candidate = self._absolute_url(page_url, a.get("href"))
                    # FIX : on ne suit pas un lien "suivant" qui pointe vers la même page
                    if candidate and candidate != page_url:
                        next_page_url = candidate
                        break

        return items, next_page_url, errors

    def scrape_competitor(self, competitor: CompetitorModel) -> ScrapeSummary:
        if not competitor.actif:
            return ScrapeSummary(
                competitor_id=competitor.id,
                competitor_name=competitor.nom,
                pages_parcourues=0,
                produits_bruts=0,
                produits_uniques=0,
                produits_enregistres=0,
                errors=["Concurrent inactif"],
                catalog_details=[],
            )

        catalogs = [
            c for c in (competitor.catalogs or [])
            if c.get("is_selected", True) and c.get("is_active", True)
        ]

        if not catalogs:
            return ScrapeSummary(
                competitor_id=competitor.id,
                competitor_name=competitor.nom,
                pages_parcourues=0,
                produits_bruts=0,
                produits_uniques=0,
                produits_enregistres=0,
                errors=["Aucun catalogue actif sélectionné"],
                catalog_details=[],
            )

        all_items = []
        all_errors = []
        catalog_details = []
        seen_product_urls: Set[str] = set()
        pages_total = 0
        raw_total = 0

        for catalog in catalogs:
            current_url = catalog["url"]
            seen_pages = set()
            page_count = 0
            catalog_raw = 0
            catalog_unique = 0
            catalog_errors = []

            while current_url and current_url not in seen_pages and page_count < 30:
                seen_pages.add(current_url)

                try:
                    html = self._get_html(current_url)
                    page_items, next_page_url, page_errors = self._extract_products_from_page(
                        current_url, html, competitor
                    )

                    raw_total += len(page_items)
                    catalog_raw += len(page_items)

                    for item in page_items:
                        if item.urlProduit not in seen_product_urls:
                            seen_product_urls.add(item.urlProduit)
                            all_items.append(item)
                            catalog_unique += 1

                    all_errors.extend(page_errors)
                    catalog_errors.extend(page_errors)

                    pages_total += 1
                    page_count += 1
                    current_url = next_page_url
                    time.sleep(0.4)

                except Exception as exc:
                    msg = f"Erreur scraping page {current_url}: {str(exc)}"
                    all_errors.append(msg)
                    catalog_errors.append(msg)
                    break

            catalog_details.append(
                CatalogScrapeDetail(
                    catalog_url=catalog["url"],
                    catalog_title=catalog.get("title"),
                    pages_parcourues=page_count,
                    produits_bruts=catalog_raw,
                    produits_uniques=catalog_unique,
                    errors=catalog_errors,
                )
            )

        save_result = self.stock_client.save_competitor_products(all_items)
        saved_rows = int(save_result.get("rows", 0))
        self.stock_client.update_last_scraping(competitor.id)

        return ScrapeSummary(
            competitor_id=competitor.id,
            competitor_name=competitor.nom,
            pages_parcourues=pages_total,
            produits_bruts=raw_total,
            produits_uniques=len(all_items),
            produits_enregistres=saved_rows,
            errors=all_errors,
            catalog_details=catalog_details,
        )

    def scrape_one(self, competitor_id: int) -> dict:
        competitor = self.stock_client.get_competitor_by_id(competitor_id)
        if competitor is None:
            raise ValueError(f"Concurrent {competitor_id} introuvable")
        return self.scrape_competitor(competitor).model_dump()

    def scrape_due_or_all(self, competitor_id: int | None = None) -> dict:
        competitors = self.stock_client.get_competitors()
        if competitor_id is not None:
            competitors = [c for c in competitors if c.id == competitor_id]

        if competitor_id is not None and not competitors:
            raise ValueError(f"Concurrent {competitor_id} introuvable")

        results = []
        total_saved = 0

        for competitor in competitors:
            summary = self.scrape_competitor(competitor)
            results.append(summary.model_dump())
            total_saved += summary.produits_enregistres

        return {
            "status": "success",
            "concurrents_traites": len(results),
            "produits_enregistres_total": total_saved,
            "results": results,
        }
