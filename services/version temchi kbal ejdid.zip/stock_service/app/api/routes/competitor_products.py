from fastapi import APIRouter, Depends, Body, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.schemas.competitor_schemas import ProductCompetitorCreate
from app.services.competitor_product_service import (
    bulk_save_scraped_competitor_products_service,
)

router = APIRouter(tags=["competitor-products"])


@router.post("/competitor-products/bulk")
def bulk_save_competitor_products(
    items: list[ProductCompetitorCreate],
    db: Session = Depends(get_db),
):
    return bulk_save_scraped_competitor_products_service(items, db)


@router.post("/competitor-products/bulk-from-scraping")
def bulk_save_competitor_products_from_scraping(
    payload=Body(...),
    db: Session = Depends(get_db),
):
    if isinstance(payload, list):
        items = payload
    elif isinstance(payload, dict):
        if "items" in payload and isinstance(payload["items"], list):
            items = payload["items"]
        elif "products" in payload and isinstance(payload["products"], list):
            items = payload["products"]
        else:
            raise HTTPException(
                status_code=422,
                detail="Body invalide. Utilise soit une liste directe, soit {'items': [...]}, soit {'products': [...]}",
            )
    else:
        raise HTTPException(
            status_code=422,
            detail="Body invalide pour /competitor-products/bulk-from-scraping",
        )

    normalized_items = []
    for item in items:
        if not isinstance(item, dict):
            raise HTTPException(
                status_code=422,
                detail="Chaque élément doit être un objet JSON",
            )

        normalized_items.append(
            ProductCompetitorCreate(
                urlProduit=item.get("urlProduit") or item.get("url_produit") or item.get("url"),
                skuConcurrent=item.get("skuConcurrent") or item.get("sku_concurrent"),
                nomProduit=item.get("nomProduit") or item.get("nom_produit") or item.get("name"),
                concurrent_id=item.get("concurrent_id") or item.get("competitor_id"),
                produit_id=item.get("produit_id") or item.get("product_id"),
                prixConcurrent=item.get("prixConcurrent") or item.get("prix_concurrent") or item.get("price"),
                isPromo=item.get("isPromo", item.get("is_promo", False)),
                disponibilite=item.get("disponibilite") or item.get("availability"),
                dateCollecte=item.get("dateCollecte") or item.get("date_collecte"),
                fiable=item.get("fiable", True),
            )
        )

    return bulk_save_scraped_competitor_products_service(normalized_items, db)