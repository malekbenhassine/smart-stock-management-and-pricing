from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import or_

from app.models.tables import ProductCompetitor, Product, Competitor
from app.schemas.competitor_schemas import ProductCompetitorCreate


def _safe_parse_date(date_str: str | None) -> datetime:
    if not date_str:
        return datetime.utcnow()
    try:
        return datetime.fromisoformat(date_str)
    except Exception:
        return datetime.utcnow()


def _normalize_text(value: str | None) -> str:
    if not value:
        return ""
    return " ".join(value.lower().strip().split())


def _find_internal_product_for_scraped_item(item: ProductCompetitorCreate, db: Session):
    if item.produit_id is not None:
        product = db.query(Product).filter(Product.id == item.produit_id).first()
        if product:
            return product

    if item.skuConcurrent:
        sku_clean = item.skuConcurrent.strip().strip("[]")
        product = db.query(Product).filter(Product.sku == sku_clean).first()
        if product:
            return product

    competitor = db.query(Competitor).filter(Competitor.id == item.concurrent_id).first()
    if not competitor:
        return None

    nom = _normalize_text(item.nomProduit)
    if nom:
        exact = db.query(Product).filter(Product.nom.ilike(item.nomProduit)).first()
        if exact:
            return exact

        tokens = [t for t in nom.replace("/", " ").replace("-", " ").split() if len(t) >= 4]
        if tokens:
            conditions = [Product.nom.ilike(f"%{token}%") for token in tokens[:5]]
            loose = db.query(Product).filter(or_(*conditions)).first()
            if loose:
                return loose

    return None


def bulk_save_scraped_competitor_products_service(
    items: list[ProductCompetitorCreate],
    db: Session,
):
    inserted = 0
    updated = 0
    skipped = 0

    for item in items:
        product = _find_internal_product_for_scraped_item(item, db)
        if not product:
            skipped += 1
            continue

        existing = db.query(ProductCompetitor).filter(
            ProductCompetitor.concurrent_id == item.concurrent_id,
            ProductCompetitor.url_produit == item.urlProduit,
        ).first()

        if existing:
            existing.sku_concurrent = item.skuConcurrent
            existing.nom_produit = item.nomProduit
            existing.produit_id = product.id
            existing.prix_concurrent = item.prixConcurrent
            existing.is_promo = item.isPromo
            existing.disponibilite = item.disponibilite
            existing.date_collecte = _safe_parse_date(item.dateCollecte)
            existing.fiable = item.fiable
            updated += 1
        else:
            obj = ProductCompetitor(
                url_produit=item.urlProduit,
                sku_concurrent=item.skuConcurrent,
                nom_produit=item.nomProduit,
                concurrent_id=item.concurrent_id,
                produit_id=product.id,
                prix_concurrent=item.prixConcurrent,
                is_promo=item.isPromo,
                disponibilite=item.disponibilite,
                date_collecte=_safe_parse_date(item.dateCollecte),
                fiable=item.fiable,
            )
            db.add(obj)
            inserted += 1

    db.commit()

    return {
        "status": "success",
        "inserted": inserted,
        "updated": updated,
        "skipped": skipped,
        "rows": inserted + updated,
        "total_received": len(items),
    }


# alias de compatibilité
bulk_save_competitor_products_service = bulk_save_scraped_competitor_products_service