import requests
from urllib.parse import urlparse


SCRAPING_SERVICE_URL = "http://scraping_service:8060"


class ScrapingServiceClient:
    def __init__(self, base_url: str = SCRAPING_SERVICE_URL) -> None:
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({"Accept": "application/json"})

    def discover_site(self, competitor_name: str, site_url: str) -> dict:
        response = self.session.post(
            f"{self.base_url}/discovery/site",
            json={
                "competitor_name": competitor_name,
                "site_url": site_url,
            },
            timeout=(10, 90),
        )
        response.raise_for_status()
        return response.json()