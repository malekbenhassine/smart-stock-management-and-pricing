from __future__ import annotations

from datetime import datetime
from typing import Optional, Set
from urllib.parse import urljoin, urlparse, urlencode, parse_qs, urlunparse
import re
import time
import requests
import urllib3

from bs4 import BeautifulSoup

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from app.schemas.scraping_schemas import (
    CompetitorModel,
    ProductCompetitorPayload,
    ScrapeSummary,
    CatalogScrapeDetail,
)
from app.services.stock_client import StockServiceClient
from app.services.selector_service import detect_selectors


PRICE_RE = re.compile(r"(\d[\d\s.,]*)\s*TND", re.IGNORECASE)

# Nombre de produits à partir duquel on considère que la page est "pleine"
# et qu'il faut tenter la pagination par construction d'URL
_FULL_PAGE_THRESHOLD = 24


def normalize_text(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    return " ".join(value.split()).strip() or None


def parse_price(value: Optional[str]) -> Optional[float]:
    if not value:
        return None

    text = value.replace("\xa0", " ").strip()
    cleaned = "".join(ch for ch in text if ch.isdigit() or ch in ",.")
    if not cleaned:
        return None

    if "," in cleaned and "." in cleaned:
        if cleaned.rfind(",") > cleaned.rfind("."):
            cleaned = cleaned.replace(".", "").replace(",", ".")
        else:
            cleaned = cleaned.replace(",", "")
    else:
        cleaned = cleaned.replace(",", ".")

    try:
        return float(cleaned)
    except ValueError:
        return None


def extract_price_from_text(text: str) -> Optional[float]:
    if not text:
        return None
    m = PRICE_RE.search(text.replace("\xa0", " "))
    if not m:
        return None
    return parse_price(m.group(1))


def looks_like_product_name(text: str) -> bool:
    if not text:
        return False

    t = " ".join(text.split()).strip()
    lower = t.lower()

    banned = [
        "détails", "voir les détails", "ajouter au panier", "acheter",
        "connexion", "create an account", "panier", "menu",
        "retour", "suivant", "précédent",
    ]
    if lower in banned:
        return False

    if len(t) < 8:
        return False

    useful_tokens = [
        "pc", "portable", "laptop", "notebook", "lenovo", "asus", "hp",
        "dell", "acer", "msi", "macbook", "iphone", "samsung", "écran",
        "ecran", "monitor", "moniteur", "ssd", "ram", "go", "tb",
        "intel", "amd", "ryzen", "core", "geforce", "rtx", "gtx",
        "processeur", "memoire", "mémoire", "disque", "clavier", "souris",
        "imprimante", "tablette", "smartphone", "telephone", "téléphone",
        "onduleur", "batterie", "chargeur", "casque", "ecouteur", "écouteur",
        "routeur", "switch", "wifi", "carte", "webcam", "scanner",
    ]
    if len(t) > 20:
        return True

    return any(tok in lower for tok in useful_tokens)


# ---------------------------------------------------------------------------
# Pagination par construction d'URL
# ---------------------------------------------------------------------------

def _detect_page_param(url: str) -> Optional[str]:
    """
    Détecte quel paramètre de pagination est déjà présent dans l'URL.
    Retourne 'p', 'page', ou None si aucun.
    """
    params = parse_qs(urlparse(url).query)
    if "p" in params:
        return "p"
    if "page" in params:
        return "page"
    return None


def _build_page_url(base_url: str, page_num: int, param: str = "p") -> str:
    """
    Construit l'URL de la page N en injectant/remplaçant le paramètre de pagination.
    Exemples :
      page 2 → https://mytek.tn/cat.html?p=2
      page 3 → https://mytek.tn/cat.html?p=3
    """
    parsed = urlparse(base_url)
    params = parse_qs(parsed.query, keep_blank_values=True)
    params[param] = [str(page_num)]
    # Aplatir les listes (parse_qs retourne des listes)
    flat_params = {k: v[0] for k, v in params.items()}
    new_query = urlencode(flat_params)
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", new_query, ""))


def _strip_page_param(url: str) -> str:
    """Retourne l'URL sans le paramètre de pagination (pour comparaison)."""
    parsed = urlparse(url)
    params = parse_qs(parsed.query, keep_blank_values=True)
    params.pop("p", None)
    params.pop("page", None)
    flat = {k: v[0] for k, v in params.items()}
    new_query = urlencode(flat) if flat else ""
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", new_query, ""))


def _extract_product_ids(soup: BeautifulSoup, product_card_sel: Optional[str]) -> set:
    """
    Extrait un ensemble d'identifiants de produits (data-id ou href)
    pour détecter si une page est identique à la précédente.
    """
    ids = set()
    if product_card_sel:
        for card in soup.select(product_card_sel):
            pid = card.get("data-id") or card.get("data-url")
            if pid:
                ids.add(pid)
    if not ids:
        for a in soup.select("a[href]"):
            href = a.get("href", "")
            if href and len(href) > 5:
                ids.add(href)
    return ids


class ScrapingService:
    def __init__(self) -> None:
        self.stock_client = StockServiceClient()
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "fr,en;q=0.9",
            "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
        })

    def _absolute_url(self, base_url: str, href: Optional[str]) -> Optional[str]:
        if not href:
            return None
        return urljoin(base_url, href)

    def _get_html(self, url: str) -> str:
        last_exc = None
        for _ in range(3):
            try:
                response = self.session.get(url, timeout=(10, 45), allow_redirects=True, verify=False)
                response.raise_for_status()
                return response.text
            except Exception as exc:
                last_exc = exc
                time.sleep(1)
        raise RuntimeError(f"Echec récupération HTML pour {url}: {last_exc}")

    def _extract_product_from_card(self, card, page_url: str, selectors: dict, competitor: CompetitorModel):
        data_name = card.get("data-name")
        data_url = card.get("data-url")
        data_sku = card.get("data-sku")
        data_price = card.get("data-final-price") or card.get("data-price")

        name_node = card.select_one(selectors.get("product_name")) if selectors.get("product_name") else None
        link_node = card.select_one(selectors.get("product_link")) if selectors.get("product_link") else None
        price_node = card.select_one(selectors.get("product_price")) if selectors.get("product_price") else None
        old_price_node = card.select_one(selectors.get("old_price")) if selectors.get("old_price") else None
        availability_node = card.select_one(selectors.get("availability")) if selectors.get("availability") else None
        sku_node = card.select_one(selectors.get("sku")) if selectors.get("sku") else None

        nom_produit = data_name or (name_node.get_text(" ", strip=True) if name_node else None)

        href = data_url
        if not href and link_node and link_node.has_attr("href"):
            href = link_node.get("href")

        url_produit = self._absolute_url(page_url, href)
        prix_concurrent = parse_price(data_price or (price_node.get_text(" ", strip=True) if price_node else None))
        ancien_prix = parse_price(old_price_node.get_text(" ", strip=True)) if old_price_node else None
        disponibilite = availability_node.get_text(" ", strip=True) if availability_node else None
        sku_concurrent = data_sku or (sku_node.get_text(" ", strip=True) if sku_node else None)

        if not nom_produit or not url_produit or prix_concurrent is None:
            return None

        return ProductCompetitorPayload(
            urlProduit=url_produit,
            skuConcurrent=sku_concurrent,
            nomProduit=nom_produit,
            concurrent_id=competitor.id,
            produit_id=None,
            prixConcurrent=prix_concurrent,
            isPromo=bool(ancien_prix and ancien_prix > prix_concurrent),
            disponibilite=normalize_text(disponibilite),
            dateCollecte=datetime.utcnow().isoformat(),
            fiable=True,
        )

    def _extract_products_without_cards(self, soup: BeautifulSoup, page_url: str, competitor: CompetitorModel):
        items = []
        seen_urls = set()

        for a in soup.select("a[href]"):
            href = a.get("href")
            text = a.get_text(" ", strip=True)

            if not href or not looks_like_product_name(text):
                continue

            absolute_url = self._absolute_url(page_url, href)
            if not absolute_url or absolute_url in seen_urls:
                continue

            parent = a.parent
            price = None
            availability = None

            probe = parent
            for _ in range(4):
                if probe is None:
                    break
                probe_text = probe.get_text(" ", strip=True)
                price = extract_price_from_text(probe_text) or price
                lower_text = probe_text.lower()
                if "hors stock" in lower_text:
                    availability = "Hors stock"
                elif "en stock" in lower_text:
                    availability = "En stock"
                elif "en arrivage" in lower_text:
                    availability = "En arrivage"
                if price is not None:
                    break
                probe = probe.parent

            if price is None:
                continue

            seen_urls.add(absolute_url)
            items.append(
                ProductCompetitorPayload(
                    urlProduit=absolute_url,
                    skuConcurrent=None,
                    nomProduit=text,
                    concurrent_id=competitor.id,
                    produit_id=None,
                    prixConcurrent=price,
                    isPromo=False,
                    disponibilite=availability,
                    dateCollecte=datetime.utcnow().isoformat(),
                    fiable=False,
                )
            )

        return items

    def _extract_products_from_page(self, page_url: str, html: str, competitor: CompetitorModel):
        soup = BeautifulSoup(html, "lxml")
        host = competitor.site_host_normalized or ""
        selectors = dict(competitor.selectors_override or {})
        if not selectors.get("product_card"):
            selectors.update(detect_selectors(host, html))

        errors = []
        items = []

        product_card_sel = selectors.get("product_card")
        cards = []

        if product_card_sel:
            try:
                cards = soup.select(product_card_sel)
            except Exception as exc:
                errors.append(f"Sélecteur product_card invalide: {exc}")

        if cards:
            for card in cards:
                try:
                    item = self._extract_product_from_card(card, page_url, selectors, competitor)
                    if item:
                        items.append(item)
                except Exception as exc:
                    errors.append(f"Erreur parsing carte sur {page_url}: {str(exc)}")

        if not items:
            fallback_items = self._extract_products_without_cards(soup, page_url, competitor)
            items.extend(fallback_items)

        # ----------------------------------------------------------------
        # Détection du lien "page suivante"
        # Stratégie 1 : sélecteur CSS configuré (lien <a href> dans le DOM)
        # ----------------------------------------------------------------
        next_page_url = None
        next_selector = selectors.get("next_page")
        if next_selector:
            try:
                next_node = soup.select_one(next_selector)
                if next_node and next_node.has_attr("href"):
                    candidate = self._absolute_url(page_url, next_node.get("href"))
                    if candidate and candidate != page_url:
                        next_page_url = candidate
            except Exception:
                pass

        # ----------------------------------------------------------------
        # Stratégie 2 : fallback texte — chercher un lien "Suivant"/"Next"
        # ----------------------------------------------------------------
        if not next_page_url:
            for a in soup.select("a[href]"):
                txt = a.get_text(" ", strip=True).lower()
                if txt in {"suivant", "next"} or "navigate_next" in txt:
                    candidate = self._absolute_url(page_url, a.get("href"))
                    if candidate and candidate != page_url:
                        next_page_url = candidate
                        break

        # ----------------------------------------------------------------
        # Stratégie 3 : pagination par construction d'URL (?p=N ou ?page=N)
        # Activée quand :
        #   - aucun lien "suivant" trouvé dans le DOM (JS-rendered pagination)
        #   - ET la page contient suffisamment de produits (page "pleine")
        # ----------------------------------------------------------------
        if not next_page_url and len(items) >= _FULL_PAGE_THRESHOLD:
            # Détecter le paramètre déjà présent, sinon utiliser "p" par défaut
            param = _detect_page_param(page_url) or "p"
            current_params = parse_qs(urlparse(page_url).query)
            current_page_num = int(current_params.get(param, ["1"])[0])
            next_page_url = _build_page_url(page_url, current_page_num + 1, param)

        return items, next_page_url, errors, soup, selectors

    def _scrape_catalog(
        self,
        catalog: dict,
        competitor: CompetitorModel,
        seen_product_urls: Set[str],
        all_items: list,
        all_errors: list,
    ) -> tuple[int, int, int, list]:
        """
        Scrape toutes les pages d'un catalogue donné.
        Retourne (pages_count, raw_count, unique_count, catalog_errors).
        """
        current_url = catalog["url"]
        base_url_stripped = _strip_page_param(current_url)

        seen_pages: Set[str] = set()
        prev_product_ids: set = set()
        page_count = 0
        catalog_raw = 0
        catalog_unique = 0
        catalog_errors = []

        while current_url and page_count < 30:
            # Normaliser l'URL pour détecter les boucles
            normalized = current_url
            if normalized in seen_pages:
                break
            seen_pages.add(normalized)

            try:
                html = self._get_html(current_url)
                page_items, next_page_url, page_errors, soup, selectors = \
                    self._extract_products_from_page(current_url, html, competitor)

                # --------------------------------------------------------
                # Détection de page vide ou identique → arrêt de pagination
                # --------------------------------------------------------
                if not page_items:
                    # Page vide : fin du catalogue
                    catalog_errors.extend(page_errors)
                    break

                product_card_sel = selectors.get("product_card")
                current_ids = _extract_product_ids(soup, product_card_sel)

                if prev_product_ids and current_ids and current_ids == prev_product_ids:
                    # Page identique à la précédente (pagination circulaire ou fin)
                    break

                prev_product_ids = current_ids

                # --------------------------------------------------------
                # Vérification anti-boucle sur les URLs construites (?p=N)
                # Pour la pagination construite, vérifier que l'URL de base
                # est bien la même catégorie
                # --------------------------------------------------------
                if next_page_url:
                    next_stripped = _strip_page_param(next_page_url)
                    if next_stripped != base_url_stripped:
                        # L'URL construite pointe vers une autre catégorie → stop
                        next_page_url = None

                catalog_raw += len(page_items)

                for item in page_items:
                    if item.urlProduit not in seen_product_urls:
                        seen_product_urls.add(item.urlProduit)
                        all_items.append(item)
                        catalog_unique += 1

                all_errors.extend(page_errors)
                catalog_errors.extend(page_errors)

                page_count += 1
                current_url = next_page_url
                time.sleep(0.5)

            except Exception as exc:
                msg = f"Erreur scraping page {current_url}: {str(exc)}"
                all_errors.append(msg)
                catalog_errors.append(msg)
                break

        return page_count, catalog_raw, catalog_unique, catalog_errors

    def scrape_competitor(self, competitor: CompetitorModel) -> ScrapeSummary:
        if not competitor.actif:
            return ScrapeSummary(
                competitor_id=competitor.id,
                competitor_name=competitor.nom,
                pages_parcourues=0,
                produits_bruts=0,
                produits_uniques=0,
                produits_enregistres=0,
                errors=["Concurrent inactif"],
                catalog_details=[],
            )

        catalogs = [
            c for c in (competitor.catalogs or [])
            if c.get("is_selected", True) and c.get("is_active", True)
        ]

        if not catalogs:
            return ScrapeSummary(
                competitor_id=competitor.id,
                competitor_name=competitor.nom,
                pages_parcourues=0,
                produits_bruts=0,
                produits_uniques=0,
                produits_enregistres=0,
                errors=["Aucun catalogue actif sélectionné"],
                catalog_details=[],
            )

        all_items: list[ProductCompetitorPayload] = []
        all_errors: list[str] = []
        catalog_details = []
        seen_product_urls: Set[str] = set()
        pages_total = 0
        raw_total = 0

        for catalog in catalogs:
            page_count, catalog_raw, catalog_unique, catalog_errors = self._scrape_catalog(
                catalog, competitor, seen_product_urls, all_items, all_errors
            )

            pages_total += page_count
            raw_total += catalog_raw

            catalog_details.append(
                CatalogScrapeDetail(
                    catalog_url=catalog["url"],
                    catalog_title=catalog.get("title"),
                    pages_parcourues=page_count,
                    produits_bruts=catalog_raw,
                    produits_uniques=catalog_unique,
                    errors=catalog_errors,
                )
            )

        save_result = self.stock_client.save_competitor_products(all_items)
        saved_rows = int(save_result.get("rows", 0))
        self.stock_client.update_last_scraping(competitor.id)

        return ScrapeSummary(
            competitor_id=competitor.id,
            competitor_name=competitor.nom,
            pages_parcourues=pages_total,
            produits_bruts=raw_total,
            produits_uniques=len(all_items),
            produits_enregistres=saved_rows,
            errors=all_errors,
            catalog_details=catalog_details,
        )

    def scrape_one(self, competitor_id: int) -> dict:
        competitor = self.stock_client.get_competitor_by_id(competitor_id)
        if competitor is None:
            raise ValueError(f"Concurrent {competitor_id} introuvable")
        return self.scrape_competitor(competitor).model_dump()

    def scrape_due_or_all(self, competitor_id: int | None = None) -> dict:
        competitors = self.stock_client.get_competitors()
        if competitor_id is not None:
            competitors = [c for c in competitors if c.id == competitor_id]

        if competitor_id is not None and not competitors:
            raise ValueError(f"Concurrent {competitor_id} introuvable")

        results = []
        total_saved = 0

        for competitor in competitors:
            summary = self.scrape_competitor(competitor)
            results.append(summary.model_dump())
            total_saved += summary.produits_enregistres

        return {
            "status": "success",
            "concurrents_traites": len(results),
            "produits_enregistres_total": total_saved,
            "results": results,
        }
