from typing import List, Optional
import requests
from pydantic import ValidationError

from app.schemas.scraping_schemas import CompetitorModel, ProductCompetitorPayload


class StockServiceClient:
    def __init__(self, base_url: str = "http://stock_service:2004") -> None:
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({"Accept": "application/json"})

    def get_competitors(self) -> List[CompetitorModel]:
        response = self.session.get(f"{self.base_url}/competitors", timeout=(10, 45))
        response.raise_for_status()
        data = response.json()

        competitors = []
        for item in data:
            try:
                competitors.append(CompetitorModel(**item))
            except ValidationError:
                continue
        return competitors

    def get_competitor_by_id(self, competitor_id: int) -> Optional[CompetitorModel]:
        response = self.session.get(f"{self.base_url}/competitors/{competitor_id}", timeout=(10, 45))
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return CompetitorModel(**response.json())

    def save_competitor_products(self, items: List[ProductCompetitorPayload]) -> dict:
        if not items:
            return {"status": "success", "rows": 0, "inserted": 0, "updated": 0, "skipped": 0}

        response = self.session.post(
            f"{self.base_url}/competitor-products/bulk-from-scraping",
            json=[item.model_dump() for item in items],
            timeout=(10, 90),
        )
        response.raise_for_status()
        return response.json()

    def update_last_scraping(self, competitor_id: int) -> dict:
        response = self.session.patch(
            f"{self.base_url}/competitors/{competitor_id}/last-scraping",
            timeout=(10, 30),
        )
        response.raise_for_status()
        return response.json()