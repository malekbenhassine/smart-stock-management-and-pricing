from fastapi import APIRouter

router = APIRouter(tags=["health"])


@router.get("/health")
def health():
    return {
        "service": "scraping_service",
        "status": "ok"
    }