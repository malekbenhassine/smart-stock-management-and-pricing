from fastapi import APIRouter, HTTPException

from app.schemas.scraping_schemas import RunNowRequest
from app.services.scraping_service import ScrapingService

router = APIRouter(prefix="/jobs", tags=["jobs"])


@router.post("/run-now")
def run_now(payload: RunNowRequest):
    scraper = ScrapingService()
    try:
        return scraper.scrape_due_or_all(competitor_id=payload.competitor_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Erreur scraping: {str(exc)}")